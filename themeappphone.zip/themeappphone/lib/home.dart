import 'package:flutter/material.dart';
import 'font.dart';
import 'homecontainer.dart';
import 'theme.dart';
import 'wallpaper.dart';
import 'profile.dart';
import 'category.dart';
import 'omg.dart';// Import the CategoryPage
// Import the ProfilePage

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  List containers = [HomePage(),CategoryPage(),OmgPage(),ProfilePage()];
  int currentContainer = 0;
  int _selectedIndex = 0;
  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;

    });
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: containers[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        items:[
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.category_outlined),
            label: 'Category',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.brush_outlined),
            label: 'OMG',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Me',
          ),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.black,
        unselectedItemColor: Colors.grey,
        onTap: _onItemTapped,
      ),

    );
  }
}

class HomePage extends StatefulWidget {
  HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List containers = [HomeContainer(),ThemeContainer(),FontContainer(),WallpaperContainer()];

  int currentContainer = 0;


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              GestureDetector(
                onTap: () {
                  // Add your logic here to handle the search action
                  print('Search tapped!');
                },
                child: Container(
                  child: Container(
                    width: 358,
                    height: 53,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      color: Colors.grey[200],
                    ),
                    child: Row(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(left: 10),
                          child: Icon(Icons.search),
                        ),
                        SizedBox(width: 10),
                        Text(
                          'Search',
                          style: TextStyle(fontSize: 16, color: Colors.grey),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              SizedBox(height: 10),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  GestureDetector(
                    onTap: () {
                      // Add your logic here to handle the Home action
                      print('Home tapped!');
                    },
                    child: TextButton(
                      onPressed: () {
                        setState(() {
                          currentContainer = 0;
                        });
                      },
                      child: Text(
                        'Home',
                        style: TextStyle(
                          fontSize: 18,
                          color: currentContainer == 0 ? Colors.black : Colors.grey, // Change text color based on selected item
                          fontWeight: currentContainer == 0 ? FontWeight.bold : FontWeight.normal, // Make text bold for selected item
                        ),
                      ),
                    ),
                  ),
                  TextButton(
                    onPressed: () {
                      setState(() {
                        currentContainer = 1;
                      });
                    },
                    child: Text(
                      'Theme',
                      style: TextStyle(
                        fontSize: 18,
                        color: currentContainer == 1 ? Colors.black : Colors.grey, // Change text color based on selected item
                        fontWeight: currentContainer == 1 ? FontWeight.bold : FontWeight.normal, // Make text bold for selected item
                      ),
                    ),
                  ),
                  TextButton(
                    onPressed: () {
                      setState(() {
                        currentContainer = 2;
                      });
                    },
                    child: Text(
                      'Fonts',
                      style: TextStyle(
                        fontSize: 18,
                        color: currentContainer == 2 ? Colors.black : Colors.grey, // Change text color based on selected item
                        fontWeight: currentContainer == 2 ? FontWeight.bold : FontWeight.normal, // Make text bold for selected item
                      ),
                    ),
                  ),
                  TextButton(
                    onPressed: () {
                      setState(() {
                        currentContainer = 3;
                      });
                    },
                    child: Text(
                      'Wallpapers',
                      style: TextStyle(
                        fontSize: 18,
                        color: currentContainer == 3 ? Colors.black : Colors.grey, // Change text color based on selected item
                        fontWeight: currentContainer == 3 ? FontWeight.bold : FontWeight.normal, // Make text bold for selected item
                      ),
                    ),
                  ),
                ],
              ),



              SizedBox(height: 20),


              //Page Change
              containers[currentContainer]
            ],
          ),
        ),
      ),

    );
  }
}

