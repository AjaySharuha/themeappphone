import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_slider.dart';

class WallpaperContainer extends StatefulWidget {
  const WallpaperContainer({Key? key}) : super(key: key);

  @override
  State<WallpaperContainer> createState() => _WallContainerState();
}

class _WallContainerState extends State<WallpaperContainer> {
  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.center,
      child: Column(
        children: [
          _buildCarousel(),
          SizedBox(height: 20),

          SizedBox(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Column(
                children: [
                  Container(
                    width: 50,
                    height: 50,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.deepPurpleAccent,
                    ),
                    child: IconButton(
                      onPressed: () {
                        // Add your logic here to handle the thumbs-up button action
                        print('Thumbs-up button pressed!');
                      },
                      icon: Icon(
                        Icons.add_chart_sharp,
                        color: Colors.white,
                      ),
                    ),
                  ),
                  SizedBox(height: 5),
                  Text(
                    'Buy',
                    style: TextStyle(fontSize: 12),
                  ),
                ],
              ),
              SizedBox(width: 70),
              Column(
                children: [
                  Container(
                    width: 50,
                    height: 50,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.red,
                    ),
                    child: IconButton(
                      onPressed: () {
                        // Add your logic here to handle the thumbs-up button action
                        print('Thumbs-up button pressed!');
                      },
                      icon: Icon(
                        Icons.icecream_rounded,
                        color: Colors.white,
                      ),
                    ),
                  ),
                  SizedBox(height: 5),
                  Text(
                    'Buy',
                    style: TextStyle(fontSize: 12),
                  ),
                ],
              ),

              SizedBox(width: 70),
              Column(
                children: [
                  Container(
                    width: 50,
                    height: 50,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.yellow,
                    ),
                    child: IconButton(
                      onPressed: () {
                        // Add your logic here to handle the thumbs-up button action
                        print('Thumbs-up button pressed!');
                      },
                      icon: Icon(
                        Icons.cake,
                        color: Colors.white,
                      ),
                    ),
                  ),
                  SizedBox(height: 5),
                  Text(
                    'Buy',
                    style: TextStyle(fontSize: 12),
                  ),
                ],
              ),
            ],
          ),
          SizedBox(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _buildContainer(Colors.red, 'Galaxy', 'assets/wall2.png'),
              _buildContainer(Colors.green, 'Free city', 'assets/wall1.jpeg'),
              _buildContainer(Colors.blue, 'Zombie', 'assets/wall3.webp'),
            ],
          ),
        ], // Closing bracket for Column children
      ), // Closing bracket for Column
    ); // Closing bracket for Align
  } // Closing bracket for build method

  Widget _buildContainer(Color color, String text, String imagePath) {
    return Column(
      children: [
        Stack(
          alignment: Alignment(0.12, 0.76),
          children: [
            Container(
              width: 105,
              height: 188,
              decoration: BoxDecoration(
                color: color,
                borderRadius: BorderRadius.circular(17),
              ),
              clipBehavior: Clip.antiAlias,
              child: Image.asset(
                imagePath,
                width: 105,
                height: 188,
                fit: BoxFit.cover,
              ),
            ),
            Container(
              width: 67,
              height: 19,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Center(
                child: Text(
                  'Apply',
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.black,
                  ),
                ),
              ),
            ),
          ],
        ),
        SizedBox(height: 5),
        Text(
          text,
          style: TextStyle(fontSize: 13),
        ),
      ],
    );
  }

  Widget _buildCarousel() {
    return CarouselSlider(
      items: [
        _buildSlide(
          gradientColors: [
            Color(0xFF07FCFC),
            Color(0xFF95F0F0),
            Color(0xFF91EDED),
            Color(0xFFA3FDFD),
          ],
          icon1Path: 'assets/flower.png',
          icon2Path: 'assets/star.png',
        ),
        _buildSlide(
          gradientColors: [
            Color(0xFFFFC793),
            Color(0xFFF7CBA2),
            Color(0xFFFFD7B2),
            Color(0xFFFFEAD8),
          ],
          icon1Path: 'assets/sunny.png',
          icon2Path: 'assets/star.png',
        ),
        _buildSlide(
          gradientColors: [
            Color(0xFF0F2239),
            Color(0xFF143358),
            Color(0xFF1A4577),
            Color(0xFF0C2D54),
          ],
          icon1Path: 'assets/sunny.png',
          icon2Path: 'assets/star.png',
        ),
      ],
      options: CarouselOptions(
        height: 150,
        enlargeCenterPage: true,
        autoPlay: true,
        aspectRatio: 12 / 9,
        autoPlayCurve: Curves.fastOutSlowIn,
        enableInfiniteScroll: true,
        autoPlayAnimationDuration: Duration(milliseconds: 800),
        viewportFraction: 0.8,
      ),
    );
  }

  Widget _buildSlide({
    required List<Color> gradientColors,
    required String icon1Path,
    required String icon2Path,
  }) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        gradient: LinearGradient(
          colors: gradientColors,
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: Stack(
        alignment: Alignment.bottomRight,
        children: [
          Positioned(
            bottom: 18,
            right: 18,
            child: Container(
              width: 80,
              height: 26,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Center(
                child: Text(
                  'Apply',
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.black,
                  ),
                ),
              ),
            ),
          ),
          Positioned(
            top: 10,
            left: 10,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Image.asset(
                  icon1Path,
                  width: 100,
                  height: 70,
                ),
                SizedBox(height: 5),
                Image.asset(
                  icon2Path,
                  width: 40,
                  height: 40,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
