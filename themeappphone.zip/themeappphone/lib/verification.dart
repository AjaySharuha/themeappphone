import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:themeapp/success.dart';

class VerificationScreen extends StatefulWidget {
  final String valueToPass;

  const VerificationScreen({Key? key, required this.valueToPass}) : super(key: key);

  @override
  _VerificationScreenState createState() => _VerificationScreenState();
}

class _VerificationScreenState extends State<VerificationScreen> {
  // Access the passed value using widget.valueToPass
  String passedValue = '';

  @override
  void initState() {
    super.initState();
    passedValue = widget.valueToPass;

    _controllers = List.generate(6, (index) => TextEditingController());
    _phoneNumberController = TextEditingController();
  }

  late String _verificationId = '';
  late List<TextEditingController> _controllers;
  late TextEditingController _phoneNumberController;

  @override
  void dispose() {
    _controllers.forEach((controller) => controller.dispose());
    _phoneNumberController.dispose(); // Dispose of phone number controller
    super.dispose();
  }

  Future<void> _verifyPhoneNumber() async {
    FirebaseAuth auth = FirebaseAuth.instance;
    String phoneNumber = _phoneNumberController.text; // Get phone number from controller
    await auth.verifyPhoneNumber(
      phoneNumber: phoneNumber,
      verificationCompleted: (PhoneAuthCredential credential) {},
      verificationFailed: (FirebaseAuthException e) {},
      codeSent: (String verificationId, int? resendToken) {
        setState(() {
          _verificationId = verificationId;
        });
      },
      codeAutoRetrievalTimeout: (String verificationId) {},
    );
  }

  Future<void> _submitOTP(BuildContext context) async {
    String otp = _controllers.map((controller) => controller.text).join();
    if (otp.isNotEmpty) {
      try {
        PhoneAuthCredential credential = PhoneAuthProvider.credential(
          verificationId: passedValue,
          smsCode: otp,
        );
        await FirebaseAuth.instance.signInWithCredential(credential);
        // Navigate to SuccessScreen upon successful verification
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => SuccessScreen()),
        );
      } catch (e) {
        // Handle verification failure
        print('Failed to verify OTP: $e');
      }
    } else {
      // Show error message if OTP is empty
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Please enter the OTP'),
      ));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Verification Code'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text(
              'Enter Verification Code',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 10),
            Text(
              'We have sent the verification code to your phone number',
              style: TextStyle(
                color: Colors.black54,
              ),
            ),

            SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                for (int i = 0; i < 6; i++)
                  OTPDigitField(controller: _controllers[i]),
              ],
            ),
            SizedBox(height: 30),
            ElevatedButton(
              onPressed: () {
                _verifyPhoneNumber(); // Verify phone number when button is pressed
                _submitOTP(context); // Submit OTP
              },
              style: ElevatedButton.styleFrom(
                primary: Color(0xFFFF4747),
                minimumSize: Size(200, 50),
              ),
              child: Text(
                'Continue',
                style: TextStyle(color: Colors.white),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class OTPDigitField extends StatelessWidget {
  final TextEditingController controller;

  const OTPDigitField({Key? key, required this.controller}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 50,
      height: 50,
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey),
        borderRadius: BorderRadius.circular(10),
      ),
      child: TextField(
        controller: controller,
        maxLength: 1,
        textAlign: TextAlign.center,
        keyboardType: TextInputType.number,
        style: TextStyle(fontSize: 20),
        decoration: InputDecoration(
          counter: Offstage(),
          border: InputBorder.none,
        ),
      ),
    );
  }
}
