import 'package:flutter/material.dart';

class OmgPage extends StatelessWidget {
  const OmgPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('OMG'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            GestureDetector(
              onTap: () {
                // Handle search action
                print('Search tapped!');
              },
              child: Container(
                width: 358,
                height: 53,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  color: Colors.grey[200],
                ),
                child: Row(
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(left: 10),
                      child: Icon(Icons.search),
                    ),
                    SizedBox(width: 10),
                    Text(
                      'Search',
                      style: TextStyle(fontSize: 16, color: Colors.grey),
                    ),
                  ],
                ),
              ),
            ),

            Text(
              'Lockscreen',
              style: TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 5),
            Expanded(
              child: GridView.builder(
                padding: EdgeInsets.symmetric(horizontal: 20),
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 5,
                  mainAxisSpacing: 5,
                  childAspectRatio: 179 / 91, // Width / Height ratio
                ),
                itemCount: 8, // Number of items in the grid view
                itemBuilder: (context, index) {
                  return _buildCategoryItem(context, index);
                },
              ),
            ),
            Text(
              'Content',
              style: TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.bold,
              ),
            ),
            Expanded(
              child: GridView.builder(
                padding: EdgeInsets.symmetric(horizontal: 20),
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 5,
                  mainAxisSpacing: 5,
                  childAspectRatio: 179 / 91, // Width / Height ratio
                ),
                itemCount: 8, // Number of items in the grid view
                itemBuilder: (context, index) {
                  return _buildCategoryItem(context, index);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCategoryItem(BuildContext context, int index) {
    return Container(
      width: 179,
      height: 91,
      decoration: BoxDecoration(
        color: Color(0xFFFF4747),
        borderRadius: BorderRadius.circular(15),
      ),
      child: Center(
        child: Text(
          'Category ${index + 1}',
          style: TextStyle(fontSize: 16),
        ),
      ),
    );
  }
}
